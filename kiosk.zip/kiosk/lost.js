// Create the scene, camera, and renderer
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();
renderer.setClearColor(0xffffff); // Set background color to white

// Append the renderer's canvas to the container div
const container = document.getElementById('container');
container.appendChild(renderer.domElement);

// Add ambient light
const ambientLight = new THREE.AmbientLight(0x404040); // Soft white light
scene.add(ambientLight);

// Add directional light
const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
directionalLight.position.set(5, 10, 7.5);
scene.add(directionalLight);

let marker; // Variable to store the marker
let startPosition = new THREE.Vector3(0, -2.5, 0.5);
let secondPosition = new THREE.Vector3(0, -2, 0.5);
let endPosition = new THREE.Vector3(-1.5, -2, 0.5);
let startTime; // To keep track of animation progress
let animationStage = 0; // To track the current stage of the animation
let isAnimating = true; // Define the state to track animation

// Load the .mtl file using MTLLoader
const mtlLoader = new THREE.MTLLoader();
mtlLoader.load('obj.mtl', function (materials) {
    materials.preload();
    
    // Load the .obj file using OBJLoader and apply the materials
    const objLoader = new THREE.OBJLoader();
    objLoader.setMaterials(materials);
    objLoader.load('tinker.obj', function (obj) {
        obj.scale.set(0.1, 0.1, 0.1); // Adjust scale factor as needed
        obj.position.set(0, 0, 0); // Center the object
        scene.add(obj);

        // Place a single marker at a fixed position
        const markerGeometry = new THREE.ConeGeometry(0.1, 0.5, 32); // radius, height, segments
        const markerMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 }); // Red color
        marker = new THREE.Mesh(markerGeometry, markerMaterial);

        marker.position.copy(startPosition); // Set initial position
        marker.rotation.z = Math.PI; // Rotate the cone 180 degrees around the Z-axis
        scene.add(marker);

        // Create the "You are here" text
        const fontLoader = new THREE.FontLoader();
        fontLoader.load('https://threejs.org/examples/fonts/helvetiker_bold.typeface.json', function (font) {
            const textGeometry = new THREE.TextGeometry('You are here', {
                font: font,
                size: 0.2, // Smaller size for the text
                height: 0.05, // Height of the text
                curveSegments: 12,
                bevelEnabled: false // Disable bevel for simplicity
            });
            const textMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 }); // Red color
            const textMesh = new THREE.Mesh(textGeometry, textMaterial);

            textGeometry.center();
            textMesh.position.set(0, -2.5, 0.5); // Set position of the text

            scene.add(textMesh);

            console.log('Marker and text added:', marker, textMesh);
        });
    }, undefined, function (error) {
        console.error('An error happened while loading the model:', error);
    });
});

// Define variables for text and image
let endText;
let endImage;

// Load image and create a texture
const textureLoader = new THREE.TextureLoader();
textureLoader.load('lostandfound.jpg', function(texture) {
    const imageGeometry = new THREE.PlaneGeometry(1, 1); // Adjust size as needed
    const imageMaterial = new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide });
    endImage = new THREE.Mesh(imageGeometry, imageMaterial);
    endImage.position.set(-1.5, -1, 0.5); // Adjust position as needed
    endImage.visible = false; // Initially hidden
    scene.add(endImage);
});

function createEndText() {
    const fontLoader = new THREE.FontLoader();
    fontLoader.load('https://threejs.org/examples/fonts/helvetiker_bold.typeface.json', function(font) {
        const textGeometry = new THREE.TextGeometry('LOST AND FOUND', {
            font: font,
            size: 0.2,
            height: 0.1,
            curveSegments: 12,
            bevelEnabled: false
        });
        const textMaterial = new THREE.MeshBasicMaterial({ color: 0x000000 });
        endText = new THREE.Mesh(textGeometry, textMaterial);
        textGeometry.center();
        endText.position.set(-1.5, -0.3, 0.5); // Adjust position as needed
        endText.visible = false; // Initially hidden
        scene.add(endText);
    });
}
createEndText();

// Set the initial camera position
let initialCameraPosition = new THREE.Vector3(0, 0, 5); // Initial camera position
camera.position.copy(initialCameraPosition);

// Add OrbitControls for camera control
const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.25;
controls.enableZoom = true;
controls.enablePan = true;

// Raycaster for detecting clicks
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

// Track the zoom state
let isZoomedIn = false;

// Function to handle click events
function onMouseClick(event) {
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);

    const intersects = raycaster.intersectObject(marker);

    console.log('Raycaster intersects:', intersects); // Debugging information

    if (intersects.length > 0) {
        console.log('Marker clicked'); // Debugging information

        if (!isZoomedIn) {
            // Zoom in when marker is clicked
            const selectedMarker = intersects[0].object;
            camera.position.set(
                selectedMarker.position.x,
                selectedMarker.position.y + 0.5, // Slightly above the marker
                selectedMarker.position.z + 1 // Move closer in Z direction
            );
            camera.lookAt(selectedMarker.position);
            isZoomedIn = true;
        } else {
            // Zoom out when clicked again
            camera.position.copy(initialCameraPosition); // Reset to the initial camera position
            camera.lookAt(scene.position); // Reset the camera to look at the center of the scene
            isZoomedIn = false;
        }
    } else {
        console.log('No intersection'); // Debugging information
    }
}

// Add the click event listener
window.addEventListener('click', function(event) {
    console.log('Click event detected');
    onMouseClick(event);
});

// Animation loop
function animate() {
    if (resizeRendererToDisplaySize(renderer)) {
        controls.update();
    }

    if (marker && isAnimating) {
        const time = performance.now();
        const duration = 2000; // Duration in milliseconds
        if (!startTime) startTime = time;

        const elapsed = time - startTime;
        const progress = Math.min(elapsed / duration, 1);

        if (animationStage === 0) {
            marker.position.lerpVectors(startPosition, secondPosition, progress);
            if (progress === 1) {
                animationStage = 1;
                startTime = time; // Reset start time for the next stage
            }
        } else if (animationStage === 1) {
            marker.position.lerpVectors(secondPosition, endPosition, progress);
            if (progress === 1) {
                isAnimating = false;
                startTime = null;

                // Show text and image when animation ends
                if (endText) endText.visible = true;
                if (endImage) endImage.visible = true;
            }
        }
    }

    requestAnimationFrame(animate);
    renderer.render(scene, camera);
}
animate();

// Handle window resize
window.addEventListener('resize', () => {
    resizeRendererToDisplaySize(renderer);
});

function resizeRendererToDisplaySize(renderer) {
    const canvas = renderer.domElement;
    const width = container.clientWidth;
    const height = container.clientHeight;
    const needResize = canvas.width !== width || canvas.height !== height;
    if (needResize) {
        renderer.setSize(width, height, false);
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
    }
    return needResize;
}
