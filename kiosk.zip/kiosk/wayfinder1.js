// Create the scene, camera, and renderer
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();
renderer.setClearColor(0xffffff); // Set background color to white

// Append the renderer's canvas to the container div
const container = document.getElementById('container');
container.appendChild(renderer.domElement);

// Add ambient light
const ambientLight = new THREE.AmbientLight(0x404040); // Soft white light
scene.add(ambientLight);

// Add directional light
const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
directionalLight.position.set(5, 10, 7.5);
scene.add(directionalLight);

let markers = [], colliders = [], isZoomedIn = [];
let textMesh, imageMesh; // Variables to store the text mesh and image mesh

// Load the .mtl file using MTLLoader
const mtlLoader = new THREE.MTLLoader();
mtlLoader.load('Departure/obj.mtl', function (materials) {
    materials.preload();

    // Load the .obj file using OBJLoader and apply the materials
    const objLoader = new THREE.OBJLoader();
    objLoader.setMaterials(materials);
    objLoader.load('Departure/tinker.obj', function (obj) {
        obj.scale.set(0.1, 0.1, 0.1); // Adjust scale factor as needed
        obj.position.set(0, 0, 0); // Center the object
        scene.add(obj);

        // Create Markers and Colliders
        function createMarkerAndCollider(position, color, markerIndex, text, image) {
            // Marker size: width smaller
            const markerGeometry = new THREE.ConeGeometry(0.3, 0.6, 32); // Reduced width, height kept
            const markerMaterial = new THREE.MeshBasicMaterial({ color });
            const marker = new THREE.Mesh(markerGeometry, markerMaterial);
            marker.position.copy(position);
            marker.rotation.x = Math.PI;
            scene.add(marker);

            // Collider size: width smaller
            const colliderGeometry = new THREE.BoxGeometry(0.3, 1.0, 0.7); // Reduced width, height kept
            const colliderMaterial = new THREE.MeshBasicMaterial({ visible: false });
            const collider = new THREE.Mesh(colliderGeometry, colliderMaterial);
            collider.position.copy(position);
            scene.add(collider);

            // Store references
            markers[markerIndex] = marker;
            colliders[markerIndex] = collider;
            isZoomedIn[markerIndex] = false;

            // Store text and image data
            marker.userData = { text, image };
        }

        // Example markers and colliders with placeholders, replace with actual positions and colors
        createMarkerAndCollider(new THREE.Vector3(0, 1.5, 0.5), 0xff0000, 0, 'SECURITY CHECK', 'security.jpg');
        createMarkerAndCollider(new THREE.Vector3(0, 0.7, 0.5), 0x00ff00, 1, 'IMMIGRATION', 'immigration.png');
        createMarkerAndCollider(new THREE.Vector3(0, 0.05, 0.5), 0x0000ff, 2, 'USER CHARGE', 'service.jpg');
        createMarkerAndCollider(new THREE.Vector3(-1.5, -1.5, 0.5), 0xffff00, 3, 'CHECK-IN-COUNTER', 'counter.jpg');
        createMarkerAndCollider(new THREE.Vector3(1.5, -1.5, 0.5), 0xff00ff, 4, 'CHECK-IN-COUNTER', 'counter.jpg');
        createMarkerAndCollider(new THREE.Vector3(-3, -3.5, 0.5), 0x00ffff, 5, 'JOLLIBEE', 'jollibee.jpg');
        createMarkerAndCollider(new THREE.Vector3(-0.5, -1.5, 0.5), 0xffa500, 6, 'PNB', 'bank1.jpg');
        createMarkerAndCollider(new THREE.Vector3(0.5, -1.5, 0.5), 0x800080, 7, 'PHILTRUST', 'bank.jpg');
        createMarkerAndCollider(new THREE.Vector3(0, -2.5, 0.5), 0x008000, 8, 'HELP DESK', 'helpdesk.jpg');
        createMarkerAndCollider(new THREE.Vector3(-0.5, 1, 0.5), 0x800000, 9, 'SNACK BAR', 'snackbar.jpg');
        createMarkerAndCollider(new THREE.Vector3(0.5, 1, 0.5), 0x000080, 10, 'SUBWAY', 'subway.jpg');

        console.log('Markers and colliders added');
    }, undefined, function (error) {
        console.error('An error happened while loading the model:', error);
    });
});

// Set the initial camera position
camera.position.set(0, 0.1, 5);
camera.lookAt(0, 0, 0);

// Add OrbitControls for camera control
const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.25;
controls.enableZoom = true;
controls.enablePan = true;

// Raycaster for detecting clicks
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

function onMouseMove(event) {
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);

    const intersects = raycaster.intersectObjects(colliders);

    if (intersects.length > 0) {
        document.body.classList.add('cursor-pointer');
    } else {
        document.body.classList.remove('cursor-pointer');
    }
}

function onMouseClick(event) {
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);

    const intersects = raycaster.intersectObjects(colliders);

    if (intersects.length > 0) {
        const intersectedObject = intersects[0].object;
        const markerIndex = colliders.indexOf(intersectedObject);

        if (markerIndex !== -1) {
            const marker = markers[markerIndex];
            const { text, image } = marker.userData;
            handleMarkerClick(marker, text, image, isZoomedIn[markerIndex]);
            isZoomedIn[markerIndex] = !isZoomedIn[markerIndex];
        }
    }
}

function handleMarkerClick(marker, text, image, isZoomedIn) {
    if (!isZoomedIn) {
        camera.position.set(marker.position.x + 2, marker.position.y + 0.1, marker.position.z + 3);
        camera.lookAt(marker.position);

        if (!textMesh) {
            const loader = new THREE.FontLoader();
            loader.load('https://threejs.org/examples/fonts/helvetiker_regular.typeface.json', function (font) {
                const textGeometry = new THREE.TextGeometry(text, { font: font, size: 0.1, height: 0.02 });
                const textMaterial = new THREE.MeshBasicMaterial({ color: 0x000000 });
                textMesh = new THREE.Mesh(textGeometry, textMaterial);
                textMesh.position.set(marker.position.x - 0.35, marker.position.y + 0.2, marker.position.z + 0.6);
                scene.add(textMesh);
            });

            const textureLoader = new THREE.TextureLoader();
            textureLoader.load(image, function (texture) {
                const imageGeometry = new THREE.PlaneGeometry(0.9, 0.5);
                const imageMaterial = new THREE.MeshBasicMaterial({ map: texture, transparent: true });
                imageMesh = new THREE.Mesh(imageGeometry, imageMaterial);
                imageMesh.position.set(marker.position.x - 0.01, marker.position.y + 0.6, marker.position.z + 0.6);
                scene.add(imageMesh);
            });
        }
    } else {
        camera.position.set(0, 0.1, 5);
        camera.lookAt(0, 0, 0);

        if (textMesh) {
            scene.remove(textMesh);
            textMesh.geometry.dispose();
            textMesh.material.dispose();
            textMesh = null;
        }

        if (imageMesh) {
            scene.remove(imageMesh);
            imageMesh.geometry.dispose();
            imageMesh.material.dispose();
            imageMesh = null;
        }
    }
}

// Set the renderer's size and update on window resize
function onResize() {
    const container = document.getElementById('container');
    const width = container.clientWidth;
    const height = container.clientHeight;

    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
}

function setInitialRendererSize() {
    const container = document.getElementById('container');
    const width = container.clientWidth;
    const height = container.clientHeight;

    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
}

window.addEventListener('resize', onResize);
setInitialRendererSize(); // Call initially to set size correctly

// Add mouse and touch event listeners for click and hover
window.addEventListener('mousemove', onMouseMove);
window.addEventListener('click', onMouseClick);
window.addEventListener('touchmove', onTouchMove, { passive: true });
window.addEventListener('touchstart', onTouchStart, { passive: true });

function onTouchMove(event) {
    const touch = event.touches[0];
    const touchX = touch.clientX;
    const touchY = touch.clientY;

    // Check if the touch is within the canvas bounds
    const rect = renderer.domElement.getBoundingClientRect();
    if (touchX >= rect.left && touchX <= rect.right && touchY >= rect.top && touchY <= rect.bottom) {
        event.preventDefault();

        mouse.x = (touch.clientX / window.innerWidth) * 2 - 1;
        mouse.y = -(touch.clientY / window.innerHeight) * 2 + 1;
        raycaster.setFromCamera(mouse, camera);

        const intersects = raycaster.intersectObjects(colliders);

        if (intersects.length > 0) {
            document.body.classList.add('cursor-pointer');
        } else {
            document.body.classList.remove('cursor-pointer');
        }
    }
}

function onTouchStart(event) {
    const touch = event.touches[0];
    const touchX = touch.clientX;
    const touchY = touch.clientY;

    // Check if the touch is within the canvas bounds
    const rect = renderer.domElement.getBoundingClientRect();
    if (touchX >= rect.left && touchX <= rect.right && touchY >= rect.top && touchY <= rect.bottom) {
        event.preventDefault();

        mouse.x = (touch.clientX / window.innerWidth) * 2 - 1;
        mouse.y = -(touch.clientY / window.innerHeight) * 2 + 1;
        raycaster.setFromCamera(mouse, camera);

        const intersects = raycaster.intersectObjects(colliders);

        if (intersects.length > 0) {
            const intersectedObject = intersects[0].object;
            const markerIndex = colliders.indexOf(intersectedObject);

            if (markerIndex !== -1) {
                const marker = markers[markerIndex];
                const { text, image } = marker.userData;
                handleMarkerClick(marker, text, image, isZoomedIn[markerIndex]);
                isZoomedIn[markerIndex] = !isZoomedIn[markerIndex];
            }
        }
    }
}

// Render loop
function animate() {
    requestAnimationFrame(animate);
    controls.update(); // Only required if controls.enableDamping = true, or controls.autoRotate = true
    renderer.render(scene, camera);
}
animate();
