<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PTC</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/MTLLoader.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/OBJLoader.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tween.js/18.6.4/tween.umd.js"></script>

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Open Sans', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f0f0f0; /* Optional: Set a background color */
        }

        #container {
            width: 80%;
            max-width: 1200px; /* Adjust max width as needed */
            height: 80vh;
            max-height: 800px; /* Adjust max height as needed */
            border: 5px solid #000000; /* Black border, adjust thickness and color as needed */
            box-sizing: border-box; /* Include border in the width and height */
            background-color: #ffffff; /* Optional: Set a background color */
            position: relative;
        }

        canvas {
            display: block;
        }
		.back-button {
            position: fixed;
            top: 10px;
            left: 10px;
            background-color: #8F00FF;
            border: none;
            color: white;
            height: 40px;
            width: 40px;
            border-radius: 50%;
            text-align: center;
            line-height: 40px;
            font-size: 20px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div id="container">
	<button class="back-button" onclick="window.location.href='feedback.php';">
        <i class="fa fa-arrow-left"></i>
    </button>
        <!-- Include your Three.js script here -->
        <script src="ptc.js"></script>
    </div>
</body>

</html>
