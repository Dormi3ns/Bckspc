<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Departure</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/MTLLoader.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/OBJLoader.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tween.js/18.6.4/tween.umd.js"></script>

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Open Sans', sans-serif;
            background-color: #f0f0f0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        #container {
            width: 90%;
            max-width: 1200px;
            height: 80vh;
            max-height: 800px;
            border: 5px solid #000000;
            box-sizing: border-box;
            background-color: #ffffff;
            position: relative;
            margin-top: 80px; /* Adjusted space for the fixed search bar and buttons */
        }

        canvas {
            display: block;
            width: 100%;
            height: 100%;
        }

        .search {
            width: 100%;
            display: flex;
            justify-content: center;
            position: fixed;
            top: 0;
            left: 0;
            padding: 10px;
            background-color: #ffffff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            z-index: 100;
            box-sizing: border-box;
        }

        .search-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .search-bar {
            display: flex;
            align-items: center;
            flex: 1;
            max-width: 600px;
            border: 3px solid #8F00FF;
            border-right: none;
            padding: 0 10px;
            height: 45px;
            border-radius: 5px 0 0 5px;
            outline: none;
            color: #8F00FF;
            font-size: 16px;
            box-sizing: border-box;
        }

        .searchButton {
            border: 3px solid #8F00FF;
            background: #8F00FF;
            text-align: center;
            color: #fff;
            border-radius: 0 5px 5px 0;
            cursor: pointer;
            font-size: 16px;
            height: 45px;
            width: 80px;
            box-sizing: border-box;
        }

        .button-group {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .back-button, .l1-button, .l2-button {
            background-color: #8F00FF;
            border: none;
            color: white;
            height: 40px;
            width: 40px;
            border-radius: 50%;
            text-align: center;
            line-height: 40px;
            font-size: 20px;
            cursor: pointer;
        }

        .search-bar-container {
            display: flex;
            flex: 1;
            justify-content: center;
        }

        .back-button-container {
            margin-right: auto;
        }

        .l-buttons-container {
            margin-left: auto;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .search-bar {
                font-size: 14px;
                height: 40px;
                max-width: 500px;
            }

            .searchButton {
                height: 40px;
                font-size: 14px;
                width: 70px;
            }

            .back-button, .l1-button, .l2-button {
                height: 35px;
                width: 35px;
                font-size: 18px;
            }

            #container {
                height: 70vh;
                margin-top: 100px; /* Adjust for space taken by the search bar and buttons */
            }
        }

        @media (max-width: 480px) {
            .search-bar {
                font-size: 12px;
                height: 35px;
                max-width: 400px;
            }

            .searchButton {
                height: 35px;
                font-size: 12px;
                width: 60px;
            }

            .back-button, .l1-button, .l2-button {
                height: 30px;
                width: 30px;
                font-size: 16px;
            }

            #container {
                height: 60vh;
                margin-top: 220px; /* Adjust for space taken by the search bar and buttons */
            }
        }
    </style>
</head>
<body>
    <div class="search">
        <div class="back-button-container">
            <button class="back-button" onclick="window.location.href='index.html';">
                <i class="fa fa-arrow-left"></i>
            </button>
        </div>
        <div class="search-bar-container">
            <input type="text" id="searchInput" class="search-bar" placeholder="What are you looking for?">
            <button id="searchButton" class="searchButton">
                <i class="fa fa-search"></i>
            </button>
        </div>
        <div class="l-buttons-container">
            <button class="l1-button" onclick="window.location.href='location.php';">L1</button>
            <button class="l2-button" onclick="window.location.href='location1.php';">L2</button>
        </div>
    </div>

    <div id="container">
        <!-- Your Three.js canvas will be rendered here -->
    </div>

    <script src="wayfinder1.js"></script>
    <script>
        document.getElementById('searchButton').addEventListener('click', function() {
            var query = document.getElementById('searchInput').value.toLowerCase();
            var routes = {
                'immigration': 'bpi.php',
                'baggage claim': 'bdo.php',
                'baggageclaim': 'bdo.php',
                'baggage': 'bdo.php',
                'travel desk': 'land.php',
                'traveldesk': 'land.php',
                'travel': 'land.php',
                'pushcart': 'metro.php',
                'push cart': 'metro.php',
                'pushcarts': 'metro.php',
                'push carts': 'metro.php',
                'lost and found': 'lost.php',
                'lostandfound': 'lost.php',
                'medical clinic': 'medical.php',
                'medicalclinic': 'medical.php',
                'medical': 'medical.php',
                'clinic': 'medical.php',
                'dayroom': 'dayroom.php',
                'day room': 'dayroom.php',
                'day': 'dayroom.php',
                'dignitaries lounge': 'dig.php',
                'dignitarieslounge': 'dig.php',
                'dignitaries': 'dig.php',
                'transit lounge': 'transit.php',
                'transitlounge': 'transit.php',
                'transit': 'transit.php',
                'pnb': 'pnb.php',
                'ptc': 'ptc.php',
                'help desk': 'help.php',
                'helpdesk': 'help.php',
                'help': 'help.php',
                'check-in-counter': 'check.php',
                'check-in': 'check.php',
                'check in counter': 'check.php',
                'checkin': 'check.php',
                'check': 'check.php',
                'jollibee': 'joll.php',
                'subway': 'sub.php',
                'sub way': 'sub.php',
                'sub': 'sub.php',
                'food market': 'food.php',
                'foodmarket': 'food.php',
                'food': 'food.php',
                'market': 'food.php',
                'duty free': 'duty.php',
                'dutyfree': 'duty.php',
                'duty': 'duty.php',
                'snack bar': 'snack.php',
                'snackbar': 'snack.php',
                'snack': 'snack.php',
                'bar': 'snack.php',
                'restroom': 'cr1.php',
                'rest room': 'cr1.php',
                'cr': 'cr1.php',
                'comfort room': 'cr1.php',
                'comfortroom': 'cr1.php',
                'rest': 'cr1.php',
                'comfort': 'cr1.php'
            };

            if (routes[query]) {
                window.location.href = routes[query];
            }
        });

        document.getElementById('searchInput').addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                document.getElementById('searchButton').click();
            }
        });
    </script>
    <div><center><h1>ＤＥＰＡＲＴＵＲＥ</h1></center></div>
</body>
</html>
