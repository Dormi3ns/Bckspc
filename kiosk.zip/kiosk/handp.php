<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>Restaurants</title>
<style>
    .image-btn{
      background: none;
      border: none;
      padding: 0;
	  border:3px solid black;
	  border-radius:3px;
	  margin-top:10px;
	  margin-bottom:10px;
    }
    .image-btn img{
      display: block; /* to remove extra space below image */
  	}
	.back-button {
            position: fixed;
            top: 10px;
            left: 10px;
            background-color: #8F00FF;
            border: none;
            color: white;
            height: 40px;
            width: 40px;
            border-radius: 50%;
            text-align: center;
            line-height: 40px;
            font-size: 20px;
            cursor: pointer;
        }


</style>
</head>
<body>
<button class="back-button" onclick="window.location.href='index.html';">
        <i class="fa fa-arrow-left"></i>
    </button>
<center><h1 style="font-size: 50px;background: #00ABFF;
background: linear-gradient(to right, #00ABFF 0%, #FF2828 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;">𝕽𝖊𝖘𝖙𝖆𝖚𝖗𝖆𝖓𝖙𝖘</h1></center>
<div class="fac" style="border:3px solid black;margin-top:50px; ">
	<center><button type="button" class="image-btn" onclick="window.location.href='joll.php';">
       <img src="joll.jpg" width="250" height="200">
  	</button>
	<button type="button" class="image-btn" onclick="window.location.href='sub.php';">
       <img src="sub.png" width="250" height="200">
  	</button></center>
</center>
</div>
</body>
</html>