// Create the scene, camera, and renderer 
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();
renderer.setClearColor(0xffffff); // Set background color to white

// Append the renderer's canvas to the container div
const container = document.getElementById('container');
container.appendChild(renderer.domElement);

// Add ambient light
const ambientLight = new THREE.AmbientLight(0x404040); // Soft white light
scene.add(ambientLight);

// Add directional light
const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
directionalLight.position.set(5, 10, 7.5);
scene.add(directionalLight);

// Load the .mtl file using MTLLoader
const mtlLoader = new THREE.MTLLoader();
mtlLoader.load('Departure/obj.mtl', function (materials) {
    materials.preload();
    
    // Load the .obj file using OBJLoader and apply the materials
    const objLoader = new THREE.OBJLoader();
    objLoader.setMaterials(materials);
    objLoader.load('Departure/tinker.obj', function (obj) {
        obj.scale.set(0.1, 0.1, 0.1); // Adjust scale factor as needed
        obj.position.set(0, 0, 0); // Center the object
        scene.add(obj);
    }, undefined, function (error) {
        console.error('An error happened while loading the model:', error);
    });
});

// Define variables for text and images
let endText;
const images = []; // Array to store the images
const imagePositions = [
    
    { x: 3, y: -3, z: 0.3 }, // Position for image 4
    { x: -3, y: -3, z: 0.3 }, // Position for image 5
];

// Load images and create textures
const textureLoader = new THREE.TextureLoader();
textureLoader.load('restroom.png', function(texture) {
    for (let i = 0; i < imagePositions.length; i++) {
        const imageGeometry = new THREE.PlaneGeometry(0.3, 0.3); // Adjust size as needed
        const imageMaterial = new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide });
        const imageMesh = new THREE.Mesh(imageGeometry, imageMaterial);

        // Set positions for each image based on imagePositions array
        imageMesh.position.set(imagePositions[i].x, imagePositions[i].y, imagePositions[i].z);

        images.push(imageMesh); // Add image to the images array
        scene.add(imageMesh); // Add image to the scene
    }
});

// Add "You Are Here" text
const fontLoader = new THREE.FontLoader();
fontLoader.load('https://threejs.org/examples/fonts/helvetiker_regular.typeface.json', function (font) {
    const textGeometry = new THREE.TextGeometry('You Are Here', {
        font: font,
        size: 0.15,
        height: 0.1,
        curveSegments: 12,
        bevelEnabled: false
    });
    const textMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 }); // Red color for text
    const textMesh = new THREE.Mesh(textGeometry, textMaterial);

    textMesh.position.set(-0.6, -2.7, 0.3); // Set the position to where the highlighter is in your scene
    scene.add(textMesh);
});

// Set the initial camera position
let initialCameraPosition = new THREE.Vector3(0, 0, 5); // Initial camera position
camera.position.copy(initialCameraPosition);

// Add OrbitControls for camera control
const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.25;
controls.enableZoom = true;
controls.enablePan = true;

// Animation loop
function animate() {
    if (resizeRendererToDisplaySize(renderer)) {
        controls.update();
    }

    // Show text and image when animation ends
    if (endText) endText.visible = true;

    requestAnimationFrame(animate);
    renderer.render(scene, camera);
}
animate();

// Handle window resize
window.addEventListener('resize', () => {
    resizeRendererToDisplaySize(renderer);
});

function resizeRendererToDisplaySize(renderer) {
    const canvas = renderer.domElement;
    const width = container.clientWidth;
    const height = container.clientHeight;
    const needResize = canvas.width !== width || canvas.height !== height;
    if (needResize) {
        renderer.setSize(width, height, false);
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
    }
    return needResize;
}
