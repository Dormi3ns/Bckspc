<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
.button {
  background-color: #8F00FF;
  border: none;
  color: white;
  height:200px;
  width:300px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius:0.5%;
  border:2px solid black;
}
@import url(https://fonts.googleapis.com/css?family=Open+Sans);

.search {
  width: 100%;
  position: relative;
  top:-300px;
  right:10px;
  display: flex;
}

.searchTerm {
  width: 100%;
  border: 3px solid #8F00FF;
  border-right: none;
  padding: 10px;
  height: 50px;
  border-radius: 5px 0 0 5px;
  outline: none;
  color: #8F00FF;
  font-size:30px;
  
}

.searchTerm:focus{
  color: black;
}

.searchButton {
  width: 80px;
  height: 50px;
  border: 1px solid #8F00FF;
  background: #8F00FF;
  text-align: center;
  color: #fff;
  border-radius: 0 5px 5px 0;
  cursor: pointer;
  font-size: 20px;
}

/*Resize the wrap to see the search bar change!*/
.wrap{
  width: 90%;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.hehe{
  width: 10px;
  height: 10px;
  background-color: yellow;
  position: relative;
  left:690;
  top:459px;
  animation-name: example;
  animation-duration: 4s;
  border-radius:80%;
}

@keyframes example {
  0%   {background-color:yellow; left:690px; top:459px;}
  25%  {background-color:yellow; left:630px; top:459px;}
  50%  {background-color:yellow; left:630px; top:418px;}
  75%  {background-color:yellow; left:453px; top:418px;}
  100%  {background-color:yellow; left:453px; top:390px;}
}
</style>
<body>
<div class="container">
<div class="wrap">
 <div class="search">
      <input type="text" class="searchTerm" placeholder="What are you looking for?">
      <button type="submit" class="searchButton">
        <i class="fa fa-search"></i>
     </button>
   </div>
   </div>
   </div>
   <div class="back-button">
	<a href="handp.php" class="button" style="position:fixed;border-radius:70%;height:40px;width:40px;background-image:url(back.png);background-size:40px;"></a>
</div>
   <button style="border-radius:100%;background-size: 100%;border:0px;position:fixed;right:20px;top:5px;"><i class="fa fa-question-circle"style="font-size:48px;color:#8F00FF"></i></button>
<div class="wrapper">
   <br>
   <br>
   <br>
  <div style="border:2px solid black;height:90%;width:100%;background-image:url(burgerkingmap.png);background-repeat:no-repeat;">
  <div class="hehe"></div>
  </div>
</body>
</html>